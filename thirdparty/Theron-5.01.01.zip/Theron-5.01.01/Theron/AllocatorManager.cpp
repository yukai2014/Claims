// Copyright (C) by Ashton Mason. See LICENSE.txt for licensing information.


#include <Theron/AllocatorManager.h>


namespace Theron
{


AllocatorManager AllocatorManager::smInstance;


} // namespace Theron


