var searchData=
[
  ['null',['Null',['../classTheron_1_1ActorRef_a1d5cf851864556aa5c3c618aabf68a36.html#a1d5cf851864556aa5c3c618aabf68a36',1,'Theron::ActorRef::Null()'],['../classTheron_1_1Address_a28bd14eaddf39805b66036090c41a131.html#a28bd14eaddf39805b66036090c41a131',1,'Theron::Address::Null()']]]
];
