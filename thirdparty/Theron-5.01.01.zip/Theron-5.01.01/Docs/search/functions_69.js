var searchData=
[
  ['iallocator',['IAllocator',['../classTheron_1_1IAllocator_ad0c31c6a84b3bf476dae611ac38df1ef.html#ad0c31c6a84b3bf476dae611ac38df1ef',1,'Theron::IAllocator']]],
  ['instance',['Instance',['../classTheron_1_1AllocatorManager_ad633481820cb8f1e05ac2ce18c23cfb1.html#ad633481820cb8f1e05ac2ce18c23cfb1',1,'Theron::AllocatorManager']]],
  ['ishandlerregistered',['IsHandlerRegistered',['../classTheron_1_1Actor_a8b85886531b76f0e6aa9b46004ff6bb0.html#a8b85886531b76f0e6aa9b46004ff6bb0',1,'Theron::Actor']]]
];
