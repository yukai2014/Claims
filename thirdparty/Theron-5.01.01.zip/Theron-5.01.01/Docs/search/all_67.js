var searchData=
[
  ['getaddress',['GetAddress',['../classTheron_1_1Actor_a268613b27d2d718b55e2eb489118aa04.html#a268613b27d2d718b55e2eb489118aa04',1,'Theron::Actor::GetAddress()'],['../classTheron_1_1ActorRef_ab3f636bc01607262da610e7e78eed3e0.html#ab3f636bc01607262da610e7e78eed3e0',1,'Theron::ActorRef::GetAddress()'],['../classTheron_1_1Receiver_ade22428952084fee67865a194ade6df2.html#ade22428952084fee67865a194ade6df2',1,'Theron::Receiver::GetAddress()']]],
  ['getallocationcount',['GetAllocationCount',['../classTheron_1_1DefaultAllocator_a7aa1fb21aa04f2924e30d4eda10e2c43.html#a7aa1fb21aa04f2924e30d4eda10e2c43',1,'Theron::DefaultAllocator']]],
  ['getallocator',['GetAllocator',['../classTheron_1_1AllocatorManager_acfa9da4061ec9cc5bc738ea20cb6c135.html#acfa9da4061ec9cc5bc738ea20cb6c135',1,'Theron::AllocatorManager']]],
  ['getbytesallocated',['GetBytesAllocated',['../classTheron_1_1DefaultAllocator_a368812ccfd6bf1780a9b74360b239826.html#a368812ccfd6bf1780a9b74360b239826',1,'Theron::DefaultAllocator']]],
  ['getcountervalue',['GetCounterValue',['../classTheron_1_1Framework_a5cbe732bc768ee9a6d41e38e98e0aad8.html#a5cbe732bc768ee9a6d41e38e98e0aad8',1,'Theron::Framework']]],
  ['getframework',['GetFramework',['../classTheron_1_1Actor_afe30f86e99ff80691ec11e207711a46a.html#afe30f86e99ff80691ec11e207711a46a',1,'Theron::Actor::GetFramework()'],['../classTheron_1_1Address_a33a1cc68ee53d494a0823e379795f1dc.html#a33a1cc68ee53d494a0823e379795f1dc',1,'Theron::Address::GetFramework()']]],
  ['getmaxthreads',['GetMaxThreads',['../classTheron_1_1Framework_a7d1eec252eaf09d35787d7ff42bb4f92.html#a7d1eec252eaf09d35787d7ff42bb4f92',1,'Theron::Framework']]],
  ['getminthreads',['GetMinThreads',['../classTheron_1_1Framework_a90fe333c11791e419b3eeaeb332c5514.html#a90fe333c11791e419b3eeaeb332c5514',1,'Theron::Framework']]],
  ['getname',['GetName',['../classTheron_1_1EndPoint_a1e0996ed4cc23ab5c1bc5c48ce68d4d1.html#a1e0996ed4cc23ab5c1bc5c48ce68d4d1',1,'Theron::EndPoint']]],
  ['getnumqueuedmessages',['GetNumQueuedMessages',['../classTheron_1_1Actor_a4f6af5dba4b36bbb55ee216589ccfb63.html#a4f6af5dba4b36bbb55ee216589ccfb63',1,'Theron::Actor::GetNumQueuedMessages()'],['../classTheron_1_1ActorRef_a0bd0df0b01ee90f660581c04b48447f0.html#a0bd0df0b01ee90f660581c04b48447f0',1,'Theron::ActorRef::GetNumQueuedMessages()']]],
  ['getnumthreads',['GetNumThreads',['../classTheron_1_1Framework_a40159b92cc679a38d2f0cf45cdbdc7be.html#a40159b92cc679a38d2f0cf45cdbdc7be',1,'Theron::Framework']]],
  ['getpeakbytesallocated',['GetPeakBytesAllocated',['../classTheron_1_1DefaultAllocator_a42b6356c075558e513648eae05df21cb.html#a42b6356c075558e513648eae05df21cb',1,'Theron::DefaultAllocator']]],
  ['getpeakthreads',['GetPeakThreads',['../classTheron_1_1Framework_a15b2632e9004c3a7caa04e8d395fac3c.html#a15b2632e9004c3a7caa04e8d395fac3c',1,'Theron::Framework']]],
  ['getperthreadcountervalues',['GetPerThreadCounterValues',['../classTheron_1_1Framework_a8f56b46a4ee0f17bd6b9a4c0019c6eb0.html#a8f56b46a4ee0f17bd6b9a4c0019c6eb0',1,'Theron::Framework']]],
  ['guard_5fvalue',['GUARD_VALUE',['../classTheron_1_1DefaultAllocator_a9ad5a3063a263e545f3a3c04189b0074.html#a9ad5a3063a263e545f3a3c04189b0074',1,'Theron::DefaultAllocator']]]
];
