var searchData=
[
  ['iallocator',['IAllocator',['../classTheron_1_1IAllocator.html',1,'Theron']]]
];
